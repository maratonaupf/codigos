# -*- coding: utf-8 -*-

print "Qual o seu nome?"
nome = raw_input()
print "Bem-vindx, %s!" % nome
print "Bem-vindx,", nome + "!"
