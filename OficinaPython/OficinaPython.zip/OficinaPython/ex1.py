# -*- coding: utf-8 -*-

# Esta linha imprime "Ola Mundo" na tela.
print "Ola Mundo!"
print "Isso eh divertido."
print "Isso tambem."
print "Uhul! Print."

# Na verdade, tem muito mais comandos.
print 'Tem outro comando melhor nao?'
