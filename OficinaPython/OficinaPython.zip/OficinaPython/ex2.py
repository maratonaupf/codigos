# -*- coding: utf-8 -*-

# PEMDAS
# Parenteses
# Expoentes
# Multiplicacao
# Divisao
# Adicao
# Subtracao
print (8.9 + 5.1) / 2.0 # == 7.0
print 9.0 / 2 # == 4.5 (?)

