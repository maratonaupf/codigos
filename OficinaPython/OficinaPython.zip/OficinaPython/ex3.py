# -*- coding: utf-8 -*-

recadinho = "SALVE SALVE VACILOES"
nome = "Leonardo D. Constantin"
idade = 21 # anos
peso = 84 # kg
altura = 186 # cm

print recadinho
print "Meu nome e:", nome
print 'Eu tenho', idade, 'anos.'
print 'Eu peso', peso, 'kg. Sou muito fitness.'
print 'Eu tenho', altura, 'cm de altura.'

