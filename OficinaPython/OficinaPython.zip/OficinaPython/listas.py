# -*- coding: utf-8 -*-

frutas = "melancia uva morango abacaxi pera pitanga"
lista = frutas.split(' ')
'''
for fruta in lista:
	print fruta

print lista
'''
lista = sorted(lista)
print lista[0]
