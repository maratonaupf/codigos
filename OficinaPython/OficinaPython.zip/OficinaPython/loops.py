# -*- coding: utf-8 -*-

dory = []
print dory
# []

for i in range(0, 5):
	fish = raw_input()
	dory.append(fish)

print dory
print sorted(dory)

ordenada = sorted(dory)
print ordenada
