# -*- coding: utf-8 -*-

"""
x = "Existem %d tipos de pessoas." % 10
binario = "binario"
nao_entendem = "nao entendem"
y = "Aquelas que entendem %s e as que %s." % (binario, nao_entendem)

print x
print y

print "Eu disse: %r" % x
print "Eu tambem disse: '%s'" % y
print "Contrabarras sao \"legais\""
"""

print "Agora um poema:"
print '''
Queria ser programador,
Mas programador nao posso ser
Programador cuida da memoria
E eu so quero cuidar de voce
'''

parte1 = "Esta e a primeira metade..."
parte2 = "de uma frase com duas metades."

# print parte1 + parte2
print parte2.split(" ")