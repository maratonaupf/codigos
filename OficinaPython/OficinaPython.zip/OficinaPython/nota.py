# -*- coding: utf-8 -*-

nota1 = 8.9
nota2 = 5.1
media = (nota1 + nota2) / 2.0

print "Nota da primeira prova:", nota1
print "Nota da segunda prova:", nota2
print "Media final:", media

