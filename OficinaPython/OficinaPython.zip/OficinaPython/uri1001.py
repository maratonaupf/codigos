# -*- coding: utf-8 -*-
PI = 3.14159

raio = float(raw_input())

area = PI * raio**2

# Imprime numeros com 4 casas apos a virgula
print "A=%.4f" % area
