# -*- coding: utf-8 -*-

# TRIGGER: weight-bullying
# WHAT'S WORSE: I'm not even fat or oppressed
nome = 'Nemo'
peso = 50 # gramas

print "O Nemo eh gordo?"
if peso > 100:
	print "SIIIIIIIM!"
elif peso >= 50:
	print "Logo logo vou falar contigo em baleies"
else:
	print "Rapaz, tu ta virando passarinho"
